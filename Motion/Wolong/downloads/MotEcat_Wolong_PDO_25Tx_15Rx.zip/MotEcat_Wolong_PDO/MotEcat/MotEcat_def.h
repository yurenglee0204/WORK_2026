
/***************************************
 FName : MotEcat_def.h
 Date  : 108.05.24
 Writer: Chen, Shih-tung
 Desc. : . 07.03.13 .. 07.01.05, �s�إ�, MOT interface for ECAT;
             . �s�W SDP-E (Shihlin Electric)���䴩;
         . 07.09.18, 07.06.01, �վ� Memory Map, 0x1000 -> 0x4000;
             . _MAX_ECAT_AXIS_ == 4 -> 18; 
         . 08.05.06, �s�W _SAVE_ECAT_INFO_;
***************************************/

#include "mot_env.h"

//
#define MAX_NUM_SLAVES      20
#define _MAX_CMD_NUM_       100

#define _MAX_ECAT_AXIS_      18
#define _MAX_RMB_AXIS_       3

#define _NOT_READY_SON_      0
#define _SW_ON_DISABLE_      1
#define _READY_SW_ON_        2
#define _SWITCH_ON_          3
#define _OPERATION_          5
#define _FAULT_              9

#define _NORMAL_             0
#define _FAILED_            -10

#define _NOT_INITIATED_     -11
#define _PARAM_ERROR_       -1
#define _SERVICE_BUSY_      -2
#define _WAIT_TIMEOUT_      -5

//  Memory Map, ���: Byte; 
#define _MCMD_COMD_         0
#define _MCMD_PARM1_        4
#define _MCMD_PARM2_        8
#define _MCMD_PARM3_        12
#define _MCMD_PARM4_        16
#define _MCMD_RET_STS_      0x20
#define _MCMD_RET_VAL1_     0x24
#define _MCMD_RET_VAL2_     0x28
#define _MCMD_RET_VAL3_     0x2c
#define _MCMD_SYS_INFO_     0x80
#define _MCMD_BLK_IN_       0x0800
#define _MCMD_BLK_OUT_      0x1000
#define _MCMD_INFO_OUT_     0x2000
#define _MCMD_HRMB_IN_      0x3000
#define _MCMD_HRMB_OUT_     0x3800
//  Last: 0x0fff, for 0x1000 Bytes;

//  Command code 
#define _SDO_READ_RQ_       0x1001
#define _SDO_WRITE_RQ_      0x1002
#define _PROBE_FUNC_RQ_     0x1003
#define _HRMB_START_RQ_     0x1010
#define _HRMB_READ_RQ_      0x1011
#define _HRMB_WRITE_RQ_     0x1012
#define _DUMP_INFO_AX_      0x1100
#define _SAVE_ECAT_INFO_    0x1200
#define _OPRT_CLOSE_        0x200f

//-------------------------------------------------------
#define YASKAWA_SERVO           0x02200001
#define YASKAWA_SERVO_SIGMA7    0x02200301
#define HAL_RMB                 0x54490001

#define ECAT_DEVICE_NAMESIZE            80
//  #define EC_CFG_SLAVE_PD_SECTIONS        ((EC_T_DWORD)4)         /* amount of recv/send entries per slave processdata */

/* ecatGetCfgSlaveInfo */
typedef struct _MY_CFG_SLAVE_INFO
{
    DWORD                  dwSlaveId;              /*< out Slave ID */
    char                   abyDeviceName[ECAT_DEVICE_NAMESIZE]; /*< out Slave name */
    DWORD                  dwHCGroupIdx;           /*< out Index of the hot connect group, 0 for mandatory */
    BOOL                   bIsPresent;             /*< out Slave is currently present on bus */
    BOOL                   bIsHCGroupPresent;      /*< out Slave the hot connect group of the slave is present */

    DWORD                  dwVendorId;             /*< out Vendor identification */
    DWORD                  dwProductCode;          /*< out Product code */
    DWORD                  dwRevisionNumber;       /*< out Revision number */
    DWORD                  dwSerialNumber;         /*< out Serial number */

    WORD                   wStationAddress;        /*< out Station address */
    WORD                   wAutoIncAddress;        /*< out Auto increment address */

    DWORD                  dwPdOffsIn;             /*< out Process data offset of input data (ENI: ProcessData/Recv[1]/BitStart) */
    DWORD                  dwPdSizeIn;             /*< out Process data size of input data (ENI: ProcessData/Recv[1]/BitLength) */
    DWORD                  dwPdOffsOut;            /*< out Process data offset of output data (ENI: ProcessData/Send[1]/BitStart) */
    DWORD                  dwPdSizeOut;            /*< out Process data size of output data (ENI: ProcessData/Send[1]/BitLength) */
    DWORD                  dwPdOffsIn2;            /*< out Process data offset of input data (ENI: ProcessData/Recv[2]/BitStart) */
    DWORD                  dwPdSizeIn2;            /*< out Process data size of input data (ENI: ProcessData/Recv[2]/BitLength) */
    DWORD                  dwPdOffsOut2;           /*< out Process data offset of output data (ENI: ProcessData/Send[2]/BitStart) */
    DWORD                  dwPdSizeOut2;           /*< out Process data size of output data (ENI: ProcessData/Send[2]/BitLength) */
    DWORD                  dwPdOffsIn3;            /*< out Process data offset of input data (ENI: ProcessData/Recv[3]/BitStart) */
    DWORD                  dwPdSizeIn3;            /*< out Process data size of input data (ENI: ProcessData/Recv[3]/BitLength) */
    DWORD                  dwPdOffsOut3;           /*< out Process data offset of output data (ENI: ProcessData/Send[3]/BitStart) */
    DWORD                  dwPdSizeOut3;           /*< out Process data size of output data (ENI: ProcessData/Send[3]/BitLength) */
    DWORD                  dwPdOffsIn4;            /*< out Process data offset of input data (ENI: ProcessData/Recv[4]/BitStart) */
    DWORD                  dwPdSizeIn4;            /*< out Process data size of input data (ENI: ProcessData/Recv[4]/BitLength) */
    DWORD                  dwPdOffsOut4;           /*< out Process data offset of output data (ENI: ProcessData/Send[4]/BitStart) */
    DWORD                  dwPdSizeOut4;           /*< out Process data size of output data (ENI: ProcessData/Send[4]/BitLength) */

    DWORD                  dwMbxSupportedProtocols;/*< out Supported mailbox protocols */
    DWORD                  dwMbxOutSize;           /*< out Mailbox 1 output size (ENI: Mailbox/Send) */
    DWORD                  dwMbxInSize;            /*< out Mailbox 1 input size (ENI: Mailbox/Recv) */
    DWORD                  dwMbxOutSize2;          /*< out Mailbox 2 output size (ENI: Mailbox/Bootstrap/Send) */
    DWORD                  dwMbxInSize2;           /*< out Mailbox 2 input size (ENI: Mailbox/Bootstrap/Recv) */

    BOOL                   bDcSupport;             /*< out Slave supports DC */

    WORD                   wNumProcessVarsInp;     /*< out Number of output process data variables*/
    WORD                   wNumProcessVarsOutp;    /*< out Number of input process data variables */

    WORD                   wPrevStationAddress;    /*< Station address of the previous slave */
    WORD                   wPrevPort;              /*< Connected port of the previous slave */

    WORD                   wIdentifyAdo;           /*< out ADO used for identification command */
    WORD                   wIdentifyData;          /*< out Identification value to be validated */
    BYTE                   byPortDescriptor;       /*< out Port descriptor (ESC register  0x0007) */

    BYTE                   abyReserved[3];
    WORD                   wWkcStateDiagOffsIn[4]; /*< out Offset of WkcState bit in diagnosis image (ENI: ProcessData/Recv[1..4]/BitStart) */
    WORD                   wWkcStateDiagOffsOut[4];/*< out Offset of WkcState bit in diagnosis image (ENI: ProcessData/Send[1..4]/BitStart) */
    //  EC_T_WORD                   wWkcStateDiagOffsOut[EC_CFG_SLAVE_PD_SECTIONS];
    DWORD                  adwReserved[3];
} MY_CFG_SLAVE_INFO;
