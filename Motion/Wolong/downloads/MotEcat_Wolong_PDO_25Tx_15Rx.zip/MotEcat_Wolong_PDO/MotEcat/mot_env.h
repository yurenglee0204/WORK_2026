
/***************************************
 FName : Mot_Env.h
 Date  : 107.10.17
 Writer: Chen, Shih-tung
         . 00.05.20, �s�W AIO_8524;
         . 05.01.07, 04.12.16, �s�إ� [MotCe60_lathe_863d];
         . 05.01.18, R0 2ms, R3 10ms, DDA 2ms, TimeBase 1ms;
         . 05.02.03, �s�إ� [MotCe60_lathe_m2_8630];
             .  R0 1ms, R3 10ms, DDA 2ms, TimeBase 1ms;
         . 05.07.19, _MOT_FUN_SPCL_ == 1 ;
         . 05.07.21, R0 1ms, R3 20ms, DDA 2ms, TimeBase 1ms;
         . 07.10.17, �s�إ� [MotCe60_lathe_ecat_ev355];
             .  R0 1ms, R3 20ms, DDA 1ms, TimeBase 1ms;
***************************************/

#ifndef _MOT_ENV_DEF_
 #define _MOT_ENV_DEF_

 //  �w��(CPU);
 #define _CPU_ARM9_             0
 #define _CPU_ARM11_            0
 #define _CPU_X86_              1

 //  �w��(MOT_FPGA);
 #define _PCM_8523_             0
 #define _PCM_8504_             0
 #define _PCM_8524_             0
 #define _PCM_8630_             0

 #define _AIO_8524_             0
 #define _AIO_Am335x_           0

 //  OS ���x;
 #define _MOT_NT400_            0
 #define _MOT_CE400_            0
 #define _MOT_CE500_            0
 #define _MOT_CE600_            1

 //  �n��[�c�t��;
 #define _MAX_BOARD_            1
 #define _MAX_AXIS_             20
 #define _MAX_GROUP_NUM_        2
 #define MAX_GROUP_NUM          2
 #define _MAX_DA_CHAN_          0
 #define _REAL_AXIS_            4
 //  _MAX_AXIS_ == _MAX_BOARD_ * _AXIS_PER_BD_;
 //  _AXIS_PER_BD_ == _MAX_H8_AXIS_ + _MAX_MII_AXIS_;
 #define _MAX_H8_AXIS_          0
 #define _MAX_MII_AXIS_         20
 #define _AXIS_PER_BD_          20
 
  //  �n��\��t��;
 #define _APP_LATHE_CNC_        1
 #define _APP_MILL_CNC_         0
 #define _MOT_FUN_SPCL_         1
   //  04.12.14;
 #define _MOT_EXT_LOOP_         0
 #define _MOT_PRIVATE_          0

 //  _EXT_AXIS_NUM_ �W���� 28=32-4, �����W�L 32�줸������;
 #define _EXT_AXIS_NUM_         0

 #define MAX_GCODE_LINE         8000
 #define MAX_QUEUE_LEN          50

 //  R3 �g���ɶ�, ��� ms;
 //  _ISR_CYCLE_TIME_ == (int) ( _R3_CYCLE_TICK_ * _R0_CYCLE_TICK_ * _TICK_BASE_TIME_ );
 #define _ISR_CYCLE_TIME_       20
 //  #define _R3_CYCLE_TICK_        5
 #define _R3_CYCLE_TICK_        20
 //  _CMD_BUFFER_LEN_ == _R3_CYCLE_TICK_;
 #define _CMD_BUFFER_LEN_       20

 //  R0 �g���ɶ�, ��� ms;
 //  #define _TICK_BASE_TIME_       1.98594
 //  #define _TICK_BASE_INT_        2
 //  #define _TICK_BASE_TIME_       0.99297
 #define _TICK_BASE_TIME_       1.0
 #define _TICK_BASE_INT_        1
 #define _R0_CYCLE_TICK_        1

 //  1: 0.5ms;  2: 1.0ms;
 #define _MII_COMM_TYPE_        2
 #define _NT110_VFF_CMD_        1

#endif
