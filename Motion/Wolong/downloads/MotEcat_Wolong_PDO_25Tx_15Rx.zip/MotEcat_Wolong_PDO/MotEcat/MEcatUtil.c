
// ***************************************
//  FName : MEcatUtil.c
//  Date  : 114.12.23
//  Writer: Chen, Shih-tung
//          . 14.12.23, 14.08.12, �s�W ECAT_isr_r0_proc ����;
// ***************************************

#include <windows.h>

typedef void (*FUNC_PTR)(void);
typedef int (*pEcatR0Proc)(void);

__declspec (dllexport) int  MECAT_set_r0_func( FUNC_PTR );
__declspec (dllexport) int  iLastProcTm[10];
__declspec (dllexport) DWORD dwMEcatR0Cnt;

HANDLE hMotApiModule = NULL;

TCHAR lpMotApiFName[] = _T("MotionApi.dll");

pEcatR0Proc ECAT_isr_r0_proc = NULL;
FUNC_PTR  pISR_ecat_r0_func = NULL;

DWORD  dwMotApiLoadFlag = 0x00;

/*:: default_null_func ---------------*/
void default_null_func(void)
{
}

/*:: ISR_ecat_r0_func ----------------*/
void ISR_ecat_r0_func(void)
{
  dwMEcatR0Cnt++;
  //
  if  ( ECAT_isr_r0_proc != NULL )
      ECAT_isr_r0_proc( );
  else
      {
      if  ( pISR_ecat_r0_func != NULL )
          (*pISR_ecat_r0_func)( );
      }
}

/*:: MECAT_load_motdll ---------------*/
int  MECAT_load_motdll( void )
{
  if  ( dwMotApiLoadFlag == 1 )  return( 1 );
  
  //  hMotApiModule = LoadLibrary( _T("MotionApi.dll") );
  hMotApiModule = LoadLibrary( lpMotApiFName );
  if  ( hMotApiModule == NULL )
      {
      printf( "ERROR: MECAT_load_motdll: LoadLibrary() failed.  Get last Error = %d\n", GetLastError());
      dwMotApiLoadFlag = 88;
      return( -1 );
      }
  
  ECAT_isr_r0_proc = (pEcatR0Proc)GetProcAddress( hMotApiModule, _T("ECAT_isr_r0_proc"));
  
  if  ( ECAT_isr_r0_proc == NULL ) 
      {
      printf( "ERROR: MECAT_load_motdll: GetProcAddress() failed.  Get last Error = %d\n", GetLastError());
      dwMotApiLoadFlag = 99;
      return( -2 );
      }
  else
      {
      printf( "ECAT_isr_r0_proc = 0x%X \n", ECAT_isr_r0_proc );
      }

  dwMotApiLoadFlag = 1;

  return( 0 );
}

/*:: MECAT_unload_motdll -------------*/
int  MECAT_unload_motdll( void )
{
  if  ( dwMotApiLoadFlag == 0 )  return( 1 );
  if  ( hMotApiModule == NULL )  return( 2 );
  
  FreeLibrary( hMotApiModule );

  hMotApiModule = NULL;
  dwMotApiLoadFlag = 0;
  
  return( 0 ); 
}

/*:: MECAT_initial -------------------*/
void MECAT_initial( void )
{
  int   i;
  //  int   iRet;
  
  for (i = 0; i < 10; i++)
      iLastProcTm[i] = -1;
  dwMEcatR0Cnt = 0;
  
  //  14.12.23, �[�c�O�d;
  //  ���絲�G: ���P�� process �����J, �L�k�F��ت�!!;;
  //  iRet = MECAT_load_motdll();
  //  pISR_ecat_r0_func = default_null_func;
}

/*:: MECAT_close ---------------------*/
void MECAT_close( void )
{
  //  MECAT_unload_motdll();
}

/*:: MECAT_set_r0_func ---------------*/
int  MECAT_set_r0_func( FUNC_PTR r0_func )
{
  //  14.08.12;
  if  ( r0_func != NULL )
      pISR_ecat_r0_func = r0_func;
  
  return( 0 );
}


