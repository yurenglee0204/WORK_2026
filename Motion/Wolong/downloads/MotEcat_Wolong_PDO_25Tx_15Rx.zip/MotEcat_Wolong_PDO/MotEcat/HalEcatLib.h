#ifndef WINCE_HALECAT_LIB
#define WINCE_HALECAT_LIB

#if !defined(_HALECATLIB_WINCE_)
    #define CAPIEXPORTS  __declspec (dllimport)
#else
    #define CAPIEXPORTS  __declspec (dllexport)
#endif

#ifdef __cplusplus
extern "C"
{
#endif

	CAPIEXPORTS int HAL_ECAT_Init(char* szENIFile, int dwDCTime, int nNetType, int nNetInstance, int nVerb, PVOID pUserISR);
	CAPIEXPORTS int HAL_ECAT_Exit();
	CAPIEXPORTS int HAL_ECAT_SDODownload(DWORD dwPhysicalAddr, WORD wObIndex, BYTE byObSubIndex, BYTE* pbyData, DWORD dwDataLen,	DWORD dwTimeout, DWORD dwFlags);
	CAPIEXPORTS int HAL_ECAT_SDOUpload(DWORD dwPhysicalAddr, WORD wObIndex, BYTE byObSubIndex, BYTE* pbyData, DWORD dwDataLen, DWORD* pdwOutDataLen, DWORD dwTimeout, DWORD dwFlags);
	CAPIEXPORTS BYTE* HAL_ECAT_GetTxPDOPointer();
	CAPIEXPORTS BYTE* HAL_ECAT_GetRxPDOPointer();
	CAPIEXPORTS DWORD HAL_ECAT_GetServoTxOffset(DWORD dwType, int no, DWORD *pdwOffset, DWORD *pdwTxNumber);
	CAPIEXPORTS BOOL HAL_ECAT_GetServoRxOffset(DWORD dwType, int no, DWORD *pdwOffset, DWORD *pdwRxNumber);
	CAPIEXPORTS BOOL HAL_ECAT_GetServoPhysicalAddress(DWORD dwType, int no, DWORD *pdwAddress);
	CAPIEXPORTS DWORD HAL_ECAT_GetServoNumber(DWORD dwType);
	CAPIEXPORTS BOOL HAL_ECAT_DIOOutput(BYTE runMode, int dwType);
	CAPIEXPORTS BOOL HAL_ECAT_DIOInput(BYTE runMode, int dwType);
	CAPIEXPORTS BOOL HAL_ECAT_SetPDOPointer();
	CAPIEXPORTS BOOL HAL_ECAT_UnLoadSlaveFile();
	CAPIEXPORTS BOOL HAL_ECAT_LoadSlaveFile();
	CAPIEXPORTS BOOL HAL_ECAT_EcatState_IsOP();
	CAPIEXPORTS BOOL HAL_ECAT_GetSlaveState(DWORD dwPhysicalAddr, WORD *pwCurrState, WORD *pwReqState);
	CAPIEXPORTS BOOL HAL_ECAT_SetSlaveState(DWORD dwPhysicalAddr, WORD wReqState, DWORD dwTimeout);
	CAPIEXPORTS DWORD HAL_ECAT_GetMasterState();
	CAPIEXPORTS BOOL HAL_ECAT_SetMasterState(WORD wReqState, DWORD dwTimeout);
	CAPIEXPORTS DWORD HAL_ECAT_GetNumConnectedSlaves();
	CAPIEXPORTS DWORD HAL_ECAT_GetNumConfiguredSlaves();

#ifdef __cplusplus
}
#endif

#endif // WINCE_HALECAT_LIB